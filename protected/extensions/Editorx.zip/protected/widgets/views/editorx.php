
<script type="text/javascript">
	<?php echo "$('#editor".$id."').de77_wysiwyg();"; ?>

</script>
